"""
classe Ensemble
1. Créez une classe Ensemble pour représenter des sous-ensembles de l’ensemble des entiers compris entre 0 et N - 1,
   où N est une constante donnée, avec les méthodes suivantes :
. contient(i) : test d’appartenance,
. ajoute(i) : ajout d’un élément à l’ensemble,
. __str__() : transformation de l’ensemble en une chaîne de caractères de la forme {5 , 6, 10, 15, 20, 21, 22, 30}

Les éléments d’un ensemble seront mémorisés dans une variable d’instance de type set().

Pour essayer la classe Ensemble, écrivez un programme déterminant les nombres différents contenus dans une suite
de nombres lue sur l’entrée standard.

2. Modifiez la classe précédente afin de permettre la représentation d’ensembles d’entiers quelconques,
c’est-à-dire non nécessairement compris entre 0 et une constante N connue à l’avance.
Faites en sorte que l’interface de cette classe soit identique à celle de la version précédente
 qu’il n’y ait rien à modifier dans les programmes qui utilisent la première version de cette classe.
"""




print("Cas d'un ensemble borné")
mon_ensemble = Ensemble({-10, -3, 5, 6, 10, 15, 20, 21, 22, 30}, 20)
print(mon_ensemble)
mon_ensemble.ajoute(100)
mon_ensemble.ajoute(-1)
mon_ensemble.ajoute(1)
print(mon_ensemble)

print("Cas d'un ensemble non borné")
mon_ensemble = Ensemble({-10, -3, 5, 6, 10, 15, 20, 21, 22, 30})
print(mon_ensemble)
mon_ensemble.ajoute(100)
mon_ensemble.ajoute(-1)
mon_ensemble.ajoute(1)
print(mon_ensemble)
